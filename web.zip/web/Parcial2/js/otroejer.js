var mensaje2= "\"APP WEB\"\nCuatri:\"2026\""
alert(mensaje2)